#! /usr/bin/env python

from zplot import *

# 定义字体大小
xlabelTextSize = 14
ylabelTextSize = 14
xtitleTextSize = 14
ytitleTextSize = 14

legendTextSize = 14
legendSize = 10
legendSkip = 120

# 定义绘画区域大小、线条粗细、轴样式
dimension = [440, 150]#[240, 150]
lineWidth = 2
axisstyle = 'box'
axisticstyle = 'in'


# # 定义生成文件名、来源数据文件名
# filename = 'pload_bottleneck'
# dataname1 = 'recomputation.data'
# dataname2 = 'prefix_load_gpu.data'
# dataname3 = 'prefix_load_cpu.data'
# dataname4 = 'prefix_load_ssd.data'
# dataname5 = 'remain.data'

# # t_btm = table(file='recomputation_btm.data')
# # t_mid = table(file='recomputation_mid.data')
 

# # 创建整个画布
# ctype = 'pdf' if len(sys.argv) < 2 else sys.argv[1]
# c = canvas(ctype, title=filename, dimensions=[1600, 1000])

# # 读取源数据table
# t = table(file=dataname1)
# t2 = table(file=dataname2)
# t3 = table(file=dataname3)
# t4 = table(file=dataname4)
# t5 = table(file=dataname5)
# #t6 = table(file=dataname6)

# # d_btm = drawable(canvas=c, 
# #           xrange=[-0.8, t_btm.getmax('rownumber')+0.8]
# #           yrange=[0, 100],
# #           dimensions=[200, 33.3], coord=[50, 53])

# # d_mid = drawable(canvas=c, 
# #           xrange=[-0.8, t_btm.getmax('rownumber')+0.8],
# #           yrange=[100, 1200],
# #           dimensions=[200, 66.6], coord=[50,123]) 

# # 创建绘画框区域，定义横纵坐标轴的逻辑范围
# d = drawable(canvas=c, dimensions=dimension, coord=[50,50],
#             xrange=[-0.6, t.getmax('rownumber')+0.6], yrange=[0, 1600])

# # 绘画边框和xy轴的文字
# axis(drawable=d, style=axisstyle, ticstyle=axisticstyle,
#          doxmajortics=False, doymajortics=True,
#          xminorticcnt=0, doxminortics=False, yminorticcnt=0,
#          xtitle='Number of tokens in prefix',
#          ytitle='TTFT (s)', doylabels=True, ytitleshift=[0,0],
#          # linewidth=0.8,
#          linewidth=lineWidth,
#          xaxisposition=0, yauto=['','',400], xlabelrotate=0,
#          xlabelshift=[0, -2.5],
#          xlabelfontsize=xlabelTextSize,
#          ylabelfontsize=ylabelTextSize,
#          xtitlesize=xtitleTextSize,
#          ytitlesize=ytitleTextSize,
#          xmanual=[['256', 0], ['512', 1], ['1k', 2], ['2k', 3], ['4k', 4],['8k',5]],
#          ymanual=[['0', 0], ['400', 400], ['800', 800], ['1200', 1200],])
# c.text(coord=[d.left()-18, d.bottom()+150], rotate=0,text='1600', size=14, anchor='c,h')

# p = plotter() # 画笔
# L = legend() # 图例


# series_list = ['defalt', 'b1','b2','b3']
# fillcolors    = ['lightblue', 'lightsalmon', 'lightgrey', 'wheat', 'dodgerblue','lightgreen','orange']
# legend_names = ['recomputation', 'prefix_load_gpu', 'prefix_load_cpu', 'prefix_load_ssd']


# for i in range(len(series_list)):
#      p.verticalbars(drawable=d, table=t5,
#                xfield='rownumber', yfield=series_list[i], 
#                fill=True,
#                fillcolor=fillcolors[2],
#                barwidth=0.6, 
#                linewidth=lineWidth,
#                cluster=[i, len(series_list)])



# for i in range(len(series_list)):
#      if i== 0:
#           p.verticalbars(drawable=d, table=t4,
#                     xfield='rownumber', yfield=series_list[i], 
#                     fill=True,
#                     fillcolor=fillcolors[4],
#                     barwidth=0.6, 
#                     linewidth=lineWidth,
#                     legend = L, legendtext=legend_names[3],
#                     cluster=[i, len(series_list)])
#      else:
#           p.verticalbars(drawable=d, table=t4,
#                     xfield='rownumber', yfield=series_list[i], 
#                     fill=True,
#                     fillcolor=fillcolors[4],
#                     barwidth=0.6, 
#                     linewidth=lineWidth,
#                     cluster=[i, len(series_list)])

# for i in range(len(series_list)):
#      if i== 0:
#           p.verticalbars(drawable=d, table=t3,
#                     xfield='rownumber', yfield=series_list[i], 
#                     fill=True,
#                     fillcolor=fillcolors[3],
#                     barwidth=0.6, 
#                     linewidth=lineWidth,
#                     legend = L, legendtext=legend_names[2],
#                     cluster=[i, len(series_list)])
#      else:
#           p.verticalbars(drawable=d, table=t3,
#                     xfield='rownumber', yfield=series_list[i], 
#                     fill=True,
#                     fillcolor=fillcolors[3],
#                     barwidth=0.6, 
#                     linewidth=lineWidth,
#                     cluster=[i, len(series_list)])

# for i in range(len(series_list)):
#      if i==0:
#           p.verticalbars(drawable=d, table=t2,
#                     xfield='rownumber', yfield=series_list[i], 
#                     fill=True,
#                     fillcolor=fillcolors[1],
#                     barwidth=0.6, 
#                     linewidth=lineWidth,
#                     legend = L, legendtext=legend_names[1],
#                     cluster=[i, len(series_list)])
#      else:
#           p.verticalbars(drawable=d, table=t2,
#                     xfield='rownumber', yfield=series_list[i], 
#                     fill=True,
#                     fillcolor=fillcolors[1],
#                     barwidth=0.6, 
#                     linewidth=lineWidth,
#                     cluster=[i, len(series_list)])

# for i in range(len(series_list)):
#      if i==0:
#           p.verticalbars(drawable=d, table=t,
#                     xfield='rownumber', yfield=series_list[i], 
#                     fill=True,
#                     fillcolor=fillcolors[0],
#                     barwidth=0.6, 
#                     linewidth=lineWidth,legendtext=legend_names[0],
#                     legend = L, 
#                     cluster=[i, len(series_list)])   
#      else:
#           p.verticalbars(drawable=d, table=t,
#                     xfield='rownumber', yfield=series_list[i], 
#                     fill=True,
#                     fillcolor=fillcolors[0],
#                     barwidth=0.6, 
#                     linewidth=lineWidth,
#                     cluster=[i, len(series_list)])               



# L.draw(canvas=c, coord=[d.left()+60, d.top()+25], skipnext=2, 
#      skipspace=legendSkip,hspace=4, fontsize=legendTextSize,  
#      width=legendSize, height=legendSize,order=[3,2,1,0])

# c.render()

# 定义生成文件名、来源数据文件名
filename = 'pload_bottleneck'
# dataname1 = 'recomputation.data'
# dataname2 = 'prefix_load_gpu.data'
# dataname3 = 'prefix_load_cpu.data'
# dataname4 = 'prefix_load_ssd.data'
# dataname5 = 'remain.data'

 

# 创建整个画布
ctype = 'pdf' if len(sys.argv) < 2 else sys.argv[1]
c = canvas(ctype, title=filename, dimensions=[1600, 1000])

# 读取源数据table
t1 = table(file='recomputation.data')
t1u = table(file='recomputation_u.data')
t2 = table(file='prefix_load_gpu.data')
t2u = table(file='prefix_load_gpu_u.data')
t3 = table(file='prefix_load_cpu.data')
t3u = table(file='prefix_load_cpu_u.data')
t4 = table(file='prefix_load_ssd.data')
t4u = table(file='prefix_load_ssd_u.data')
t5 = table(file='remain.data')
t5u = table(file='remain_u.data')


# 创建绘画框区域，定义横纵坐标轴的逻辑范围
d_btm = drawable(canvas=c, 
          xrange=[-0.8, t1u.getmax('rownumber')+0.8],
          yrange=[0, 150],
          dimensions=[200, 50], coord=[50, 70])#53

d_mid = drawable(canvas=c, 
          xrange=[-0.8, t1.getmax('rownumber')+0.8],
          yrange=[200, 1200],
          dimensions=[200, 50], coord=[50,123]) 


# 绘画边框和xy轴的文字
axis(drawable=d_btm, style='xy', ticstyle='in',
         doxmajortics=False, doymajortics=True,
         xminorticcnt=0, doxminortics=False, yminorticcnt=0,
         xtitle='Number of tokens in prefix',
         ytitle='TTFT (s)', doylabels=True, ytitleshift=[0,0],
         linewidth=0.8,
         #xaxisposition=0, yauto=['','',400], 
         xlabelrotate=0,
         xlabelshift=[0, -2.5],
         xlabelfontsize=xlabelTextSize,
         ylabelfontsize=ylabelTextSize,
         xtitlesize=xtitleTextSize,
         ytitlesize=ytitleTextSize,
         xmanual=[['128',0],['256', 1], ['512', 2], ['1k', 3], ['2k', 4], ['4k', 5],['8k',6]],
         ymanual=[['30', 30], ['90', 90]])

axis(drawable=d_mid, style='y', ticstyle='in',
         doxmajortics=False, doymajortics=True,
         xminorticcnt=0, doxminortics=False, yminorticcnt=0,
         doylabels=True, ytitleshift=[0,0],
         linewidth=0.8,
         #xaxisposition=0, 
         #yauto=['','',400], xlabelrotate=0,
         xlabelshift=[0, -2.5],
         xlabelfontsize=xlabelTextSize,
         ylabelfontsize=ylabelTextSize,
         xtitlesize=xtitleTextSize,
         ytitlesize=ytitleTextSize,
         ymanual=[['200', 200],['700', 700],['1200',1200]],
         )

c.text(coord= [51,118.6],text = '/',size = 6, rotate=-30)
c.text(coord= [51,121.6],text = '/',size = 6, rotate=-30)
c.line(coord= [[50, 173],[250, 173]] , linewidth=0.8)
c.line(coord= [[250, 50],[250, 173]] , linewidth=0.8)

p = plotter() # 画笔
L = legend() # 图例


series_list = ['defalt', 'b1','b2','b3']
fillcolors    = ['lightblue', 'lightsalmon', 'lightgrey', 'orange', 'red','purple','orange']
legend_names = ['recomputation', 'prefix_load_gpu', 'prefix_load_cpu', 'prefix_load_ssd']


for i in range(len(series_list)):
     p.verticalbars(drawable=d_btm, table=t5,
               xfield='rownumber', yfield=series_list[i], 
               fill=True,
               fillcolor=fillcolors[2],
               barwidth=0.6, 
               linewidth=lineWidth,
               cluster=[i, len(series_list)])



for i in range(len(series_list)):
     if i== 0:
          p.verticalbars(drawable=d_btm, table=t4,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[4],
                    barwidth=0.6, 
                    linewidth=lineWidth,
                    legend = L, legendtext=legend_names[3],
                    cluster=[i, len(series_list)])
     else:
          p.verticalbars(drawable=d_btm, table=t4,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[4],
                    barwidth=0.6, 
                    linewidth=lineWidth,
                    cluster=[i, len(series_list)])

for i in range(len(series_list)):###cpu
     if i== 0:
          p.verticalbars(drawable=d_btm, table=t3,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[5],
                    barwidth=0.6, 
                    linewidth=lineWidth,
                    legend = L, legendtext=legend_names[2],
                    cluster=[i, len(series_list)])
     else:
          p.verticalbars(drawable=d_btm, table=t3,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[5],
                    barwidth=0.6, 
                    linewidth=lineWidth,
                    cluster=[i, len(series_list)])

for i in range(len(series_list)):#gpu
     if i==0:
          p.verticalbars(drawable=d_btm, table=t2,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[3],
                    barwidth=0.6, 
                    linewidth=lineWidth,
                    legend = L, legendtext=legend_names[1],
                    cluster=[i, len(series_list)])
     else:
          p.verticalbars(drawable=d_btm, table=t2,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[3],
                    barwidth=0.6, 
                    linewidth=lineWidth,
                    cluster=[i, len(series_list)])

for i in range(len(series_list)):#recomputation
     if i==0:
          p.verticalbars(drawable=d_btm, table=t1,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[0],
                    barwidth=0.6, 
                    linewidth=lineWidth,legendtext=legend_names[0],
                    legend = L, 
                    cluster=[i, len(series_list)])   
     else:
          p.verticalbars(drawable=d_btm, table=t1,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[0],
                    barwidth=0.6, 
                    linewidth=lineWidth,
                    cluster=[i, len(series_list)])               

######==========the upper 
for i in range(len(series_list)):
     p.verticalbars(drawable=d_mid, table=t5u,
               xfield='rownumber', yfield=series_list[i], 
               fill=True,
               fillcolor=fillcolors[2],
               barwidth=0.6, 
               linewidth=lineWidth,
               cluster=[i, len(series_list)])



for i in range(len(series_list)):
     p.verticalbars(drawable=d_mid, table=t4u,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[4],
                    barwidth=0.6, 
                    linewidth=lineWidth,
                    legend = L, 
                    cluster=[i, len(series_list)])


for i in range(len(series_list)):
          p.verticalbars(drawable=d_mid, table=t3u,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[5],
                    barwidth=0.6, 
                    linewidth=lineWidth,
                    cluster=[i, len(series_list)])

for i in range(len(series_list)):
          p.verticalbars(drawable=d_mid, table=t2u,
                    xfield='rownumber', yfield=series_list[i], 
                    fill=True,
                    fillcolor=fillcolors[3],
                    barwidth=0.6, 
                    linewidth=lineWidth,
                    cluster=[i, len(series_list)])

# for i in range(len(series_list)):
#           p.verticalbars(drawable=d_mid, table=t1u,
#                     xfield='rownumber', yfield=series_list[i], 
#                     fill=True,
#                     fillcolor=fillcolors[0],
#                     barwidth=0.6, 
#                     linewidth=lineWidth,
#                     cluster=[i, len(series_list)])               



L.draw(canvas=c, coord=[d_mid.left()+10, d_mid.top()+25], skipnext=2, 
     skipspace=legendSkip,hspace=4, fontsize=legendTextSize,  
     width=legendSize, height=legendSize)

c.render()